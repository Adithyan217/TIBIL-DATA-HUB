import json
import base64
from Crypto.Cipher import AES

secret_key = base64.b64decode("3AG9ShwSkEBbohGzF+rRINDb7qp0EM5KVB14raNvbJU=")
init_vector = base64.b64decode("ANFRvCNgbdPqBUtN")


def decrypt_function(encrypted_data: str) -> dict:
    encrypted_data_with_tag = base64.b64decode(encrypted_data)

    # Separate the encrypted data and the authentication tag
    auth_tag = encrypted_data_with_tag[-16:]
    encrypted_data = encrypted_data_with_tag[:-16]

    cipher = AES.new(secret_key, AES.MODE_GCM, nonce=init_vector)
    decrypted_bytes = cipher.decrypt_and_verify(encrypted_data, auth_tag)

    decrypted_str = decrypted_bytes.decode('utf-8')
    decrypted_data = json.loads(decrypted_str)

    return decrypted_data

def lambda_handler(event, context):
    encrypted_data = event.get('encrypted_data')
    if not encrypted_data:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid input: encrypted_data is required')
        }

    try:
        decrypted_data = decrypt_function(encrypted_data)
        return {
            'statusCode': 200,
            'body': json.dumps(decrypted_data)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error decrypting data: {str(e)}')
        }

