import json
from base64 import b64decode
import os
from Crypto.Cipher import AES




def lambda_handler(event, context):
    # Configuration
   
    body =  json.dumps(event['body'])
    encodeBody = json.loads(json.loads(body))['data']
    
    
    # data_value = enco["data"]
   
    algorithm = 'aes-256-gcm'
    secret_key =  os.getenv('secret_key').encode('utf-8');
    init_vector = os.getenv('init_vector').encode('utf-8');
    
    try:
        # Convert base64 to bytes
        # bodyData = event.data
        encrypted_data = b64decode(encodeBody)
        # ecrpyted_data =  b64decode(bodyData);
        encrypted_text = encrypted_data[:-16]  # Encrypted data without the auth tag
        auth_tag = encrypted_data[-16:]  # The last 16 bytes are the auth tag
        # Create a cipher object for decryption
        cipher = AES.new(secret_key, AES.MODE_GCM, nonce=init_vector)
        cipher.update(b'')  # In case you need to authenticate additional data

        # Decrypt the data
        decrypted = cipher.decrypt_and_verify(encrypted_text, auth_tag)
        decrypted_str = decrypted.decode('utf-8')
        print ('decrypt data', decrypted_str)
        # Set the authentication tag
    
        
        response = {
            "statusCode": 200,
            "body": json.dumps({"message":decrypted_str })
        }
        return response
        
    except Exception as e:
        print(f'Decryption failed: {str(e)}')
        raise e