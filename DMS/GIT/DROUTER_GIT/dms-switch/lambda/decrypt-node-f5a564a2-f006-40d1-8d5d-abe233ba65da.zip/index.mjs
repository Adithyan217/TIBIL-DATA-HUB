
import * as crypto from 'crypto';
export const handler = async (event) => {
 const body = JSON.parse(event.body);
  console.log('event logs', body);

// Configuration
const algorithm = 'aes-256-gcm';
const secretKey = Buffer.from(process.env.secret_key, 'utf8');
const initVector = Buffer.from(process.env.init_vector, 'utf8');


 try {
    
    
    const encryptedData = Buffer.from( body.data, 'base64');

    
    const encryptedText = encryptedData.slice(0, encryptedData.length - 16);
    const authTag = encryptedData.slice(encryptedData.length - 16);

    const decipher = crypto.createDecipheriv(algorithm, secretKey, initVector);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    const decryptedStr  = decrypted.toString('utf8');
    const response = {
    statusCode: 200,
     body: JSON.stringify({ message: decryptedStr }),
  };
  return response; 
   

    
  } catch (err) {
    console.error('Decryption failed:', err.message);
    throw err;
  }
  
  // TODO implement
  
};
